﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
string path = "data.txt";
using (FileStream fs = new FileStream(path, FileMode.Create))
{
    using (StreamWriter sw = new StreamWriter(fs, Encoding.UTF8))
    {
        sw.Writeline("username: myUsername");
        sw.Writeline("password: myPassword");
    }
}